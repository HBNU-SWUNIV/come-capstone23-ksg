"use strict";

exports.__esModule = true;
exports.default = typeof global === "undefined" ? self : global;